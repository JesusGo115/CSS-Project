//***********************

//Name: Jesus "Chuy" Gomez
//Date:
//Program Name:

//***********************

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>

#include "Player.hpp"


Player::Player(std::string name, int clas)
{
    //ctor
}
