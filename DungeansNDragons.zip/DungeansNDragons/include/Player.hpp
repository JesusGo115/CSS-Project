#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <string>


class Player
{
    public:
        Player(std::string name, int clas);
        //Getters
        std::string getName()const {return this->name;}
        int getHP()const {return this->hp;}
        int getATK()const {return this->atk;}
        int getDEF()const {return this->def;}
        int getSPD()const {return this->spd;}
        int getRES()const {return this->res;}
        int getLVL()const {return this->level;}
        int getEXP()const {return this->exp;}
        //Setters
        void setHP(int hp) {this->hp = hp;}
        void setATK(int atk) {this->atk = atk;}
        void setDEF(int def) {this->def = def;}
        void setSPD(int spd) {this->spd = spd;}
        void setRES(int res) {this->res = res;}
        void setLVL(int level) {this->level = level;}
        void setEXP(int exp) {this->exp = exp;}



    private:
        std::string name;
        Item item;
        int hp, atk, def, spd, res;
        int level, exp;
};

#endif // PLAYER_HPP
